# Florr.io 新版AFK相关视频列表

## 视频清单

1. [florr.io]如何在现版本afk without games（B站首发）- 114514___qwq
   - 发布时间: 2025-02-12
   - 视频长度: 01:08
   - URL: https://www.bilibili.com/video/BV1878y1Z7Ug/
   - 关键内容: 展示如何在现版本中实现afk而不触发游戏检测

2. 「florr」已解决新版轨迹afk - Info怒怒
   - 发布时间: 2025-01-22
   - 视频长度: 00:11
   - URL: https://www.bilibili.com/video/BV1Yx4y1L7Ld/
   - 关键内容: 展示解决新版轨迹afk的方法

3. florr io :sewer afk max rate - 2545tech
   - 发布时间: 2025-01-20
   - 视频长度: 18:45
   - URL: https://www.bilibili.com/video/BV1og411479M/
   - 关键内容: 展示下水道区域的最大效率afk方法

4. [florr.io]有关如何解决白蚁AFK房不够问题 - Gloom-shroom_
   - 发布时间: 2023-05-21
   - 视频长度: 06:32
   - URL: https://www.bilibili.com/video/BV1KY411Q7Bs/
   - 关键内容: 解决白蚁区域AFK房间不足的问题

5. 【florr】afk super spider - C76GN
   - 发布时间: 2023-08-24
   - 视频长度: 02:22
   - URL: https://www.bilibili.com/video/BV1Pp4y1T7nJ/
   - 关键内容: 展示super spider区域的afk方法

6. florr.io - 火蚁穴20min合卡，我竟然合出了.......and super afk check - HZpp取什么名字
   - 发布时间: 2024-04-04
   - 视频长度: 02:09
   - URL: https://www.bilibili.com/video/BV1Fr421t7dd/
   - 关键内容: 展示火蚁穴区域的afk检测方法

7. florr.io - 又入沙漠W33（egg+stick afk team?）- jyh2022
   - 发布时间: 2022-12-29
   - 视频长度: 未知
   - URL: https://www.bilibili.com/video/BV1og411479M/
   - 关键内容: 展示沙漠区域的afk团队配置

8. 【florr.io】afk in sewers - 7708_eat_1222
   - 发布时间: 2023-01-28
   - 视频长度: 未知
   - URL: https://www.bilibili.com/video/BV1KY411Q7Bs/
   - 关键内容: 展示下水道区域的afk方法

9. florr挂机程序最新版来啦 - 慕鱼落喵
   - 发布时间: 2024-08-08
   - 视频长度: 01:14
   - URL: https://www.bilibili.com/video/BV1og411479M/
   - 关键内容: 展示最新版本的挂机程序

10. 【Florr.io】wwt 新版本地狱solo赌徒思路 - Bob_Rainbow
    - 发布时间: 2025-01-22
    - 视频长度: 05:47
    - URL: https://www.bilibili.com/video/BV1og411479M/
    - 关键内容: 展示新版本地狱区域的solo赌徒思路

## 待收集视频

需要继续收集10个相关视频以达到20个目标。
